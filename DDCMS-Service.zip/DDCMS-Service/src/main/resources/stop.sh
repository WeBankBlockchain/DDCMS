#!/bin/bash
pgrep -f ddcms |  xargs kill -9