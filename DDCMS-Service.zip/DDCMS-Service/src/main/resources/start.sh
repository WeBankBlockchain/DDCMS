#!/usr/bin/env bash
nohup java -jar ddcms*.jar --spring.config.location=./conf/application.yml &

