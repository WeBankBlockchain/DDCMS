package com.webank.ddcms.bo;

import lombok.Data;

@Data
public class HotProductBO {
  private String productName;
  private Long productId;
}
