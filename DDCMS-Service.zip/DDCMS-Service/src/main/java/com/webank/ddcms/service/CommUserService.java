package com.webank.ddcms.service;

import com.webank.ddcms.dao.entity.CommuserInfoEntity;
import com.webank.ddcms.vo.common.CommonResponse;

/**
 * @author 张宇豪
 * @date 2023/9/4 3:55
 * @desc Github第三方业务接口
 */
public interface CommUserService {

    /**
     * 通过Github第三方实现登录
     * @param commuserInfoEntity 第三方登录的信息
     * @return 返回结果
     */
    CommonResponse githubLogin(CommuserInfoEntity commuserInfoEntity);


    /**
     * 根据用户查询第三方账号信息
     * @param username 用户名
     * @return 返回结果
     */
    CommuserInfoEntity selectByUsername(String username);


    /**
     * 新增第三方账户信息
     * @param commuserInfoEntity 第三方账户信息
     * @return 返回结果
     */
    int insertCommUser(CommuserInfoEntity commuserInfoEntity);
}
