package com.webank.ddcms.dao.mapper;

import com.webank.ddcms.dao.entity.AccountInfoEntity;
import com.webank.ddcms.dao.entity.CommuserInfoEntity;
import org.apache.ibatis.annotations.*;

/**
 * @author 张宇豪
 * @date 2023/9/4 3:55
 * @desc 第三方登录的数据库操作接口
 */
public interface CommUserInfoMapper {

    /**
     * 新增第三方账户信息
     * @param commuserInfoEntity 第三方账户信息实体类
     * @return 返回结果
     */
    @Insert(
            "INSERT INTO t_commuser_info (comm_username,account_username, type, avatar, source) values(#{commUsername},#{accountUsername}, #{type}, #{avatar}, #{source})")
    @Options(useGeneratedKeys = true, keyProperty = "pkId", keyColumn = "pk_id")
    int insertCommUser(CommuserInfoEntity commuserInfoEntity);

    /**
     * 根据用户名查询第三方账号信息
     * @param commUsername 第三方用户名
     * @return 返回结果
     */
    @Select("SELECT * FROM t_commuser_info WHERE comm_username=#{commUsername}")
    @ResultType(CommuserInfoEntity.class)
    CommuserInfoEntity selectByUserName(@Param("commUsername") String commUsername);

}
