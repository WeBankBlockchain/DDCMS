package com.webank.ddcms.enums;

public enum AccountStatus {
  UnRegistered,
  Registered,
  Approved,
  Denied
}
