package com.webank.ddcms.service.impl;

import com.webank.ddcms.bo.LoginUserBO;
import com.webank.ddcms.dao.entity.AccountInfoEntity;
import com.webank.ddcms.dao.entity.CommuserInfoEntity;
import com.webank.ddcms.dao.mapper.AccountInfoMapper;
import com.webank.ddcms.dao.mapper.CommUserInfoMapper;
import com.webank.ddcms.enums.AccountStatus;
import com.webank.ddcms.enums.AccountType;
import com.webank.ddcms.enums.CodeEnum;
import com.webank.ddcms.handler.JwtTokenHandler;
import com.webank.ddcms.service.AccountService;
import com.webank.ddcms.service.CommUserService;
import com.webank.ddcms.vo.common.CommonResponse;
import com.webank.ddcms.vo.response.LoginResponse;
import org.aspectj.apache.bcel.classfile.Code;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Objects;

/**
 * @author 张宇豪
 * @date 2023/9/4 3:55
 * @desc 第三方账户登录的实现类
 */
@Service
public class CommUserServiceImpl implements CommUserService {

    @Autowired private CommUserInfoMapper commUserInfoMapper;

    @Autowired private AccountInfoMapper accountInfoMapper;

    @Autowired private AuthenticationManager authenticationManager;

    @Autowired private JwtTokenHandler tokenHandler;

    /**
     * 实现第三方登录的信息
     * @param commuserInfoEntity 第三方登录的信息
     * @return
     */
    @Override
    public CommonResponse githubLogin(CommuserInfoEntity commuserInfoEntity) {
        // 查询当前的第三方账户是否已经注册
        CommuserInfoEntity result = this.selectByUsername(commuserInfoEntity.getCommUsername());
        if (Objects.isNull(result))
        {
            return CommonResponse.error(CodeEnum.USER_NOT_EXISTS);
        }
        // 根据第三方的账户查询当前的AccountUser的信息
        AccountInfoEntity accountInfoEntity =
                accountInfoMapper.selectByUserName(result.getAccountUsername());
        if (Objects.isNull(accountInfoEntity))
        {
            // 用户未绑定第三方账户
            return CommonResponse.error(CodeEnum.USER_NOT_EXISTS);
        }
        // 判断当前第三方账户是否绑定成功
        if (!result.getAccountUsername().equals(accountInfoEntity.getUserName()))
        {
            return CommonResponse.error(CodeEnum.USER_NOT_EXISTS);
        }
        // 登录的权限校验
        if (accountInfoEntity.getAccountType() != AccountType.ADMIN.getRoleKey()
                && accountInfoEntity.getStatus() != AccountStatus.Approved.ordinal()) {
            return CommonResponse.error(CodeEnum.ACCOUNT_NOT_APPROVED);
        }
        // 这里使用的是SpringSecurity所以我保留了默认的 生成Token的时候我使用的是DID + Github的AccessToken
        try {
            // 使用auth进行用户认证
            UsernamePasswordAuthenticationToken authenticationToken =
                    new UsernamePasswordAuthenticationToken(accountInfoEntity.getUserName(), "0");
            // 调用UserDetailService实现类的认证方法
            Authentication authentication = authenticationManager.authenticate(authenticationToken);

            // 认证通过，则生成token，并返回
            LoginUserBO loginInfoBo = (LoginUserBO) authentication.getPrincipal();

            // 这里的Token组成使用DID + Github的AccessToken
            String token =
                    JwtTokenHandler.TOKEN_PREFIX
                            + tokenHandler.generateToken(loginInfoBo.getEntity().getDid() + commuserInfoEntity.getAccessToken());
            LoginResponse response = new LoginResponse();
            response.setToken(token);
            response.setAccountType(String.valueOf(accountInfoEntity.getAccountType()));
            return CommonResponse.success(response);
        } catch (AuthenticationException e) {
            return CommonResponse.error(CodeEnum.LOGIN_FAILED);
        }
    }

    /**
     * 根据用户名查询第三方账户信息
     * @param username 用户名
     * @return 返回结果
     */
    @Override
    public CommuserInfoEntity selectByUsername(String username) {
        return commUserInfoMapper.selectByUserName(username);
    }

    /**
     * 新增第三方账户信息
     * @param commuserInfoEntity 第三方账户信息
     * @return 返回结果
     */
    @Override
    public int insertCommUser(CommuserInfoEntity commuserInfoEntity) {
        return commUserInfoMapper.insertCommUser(commuserInfoEntity);
    }
}
