package com.webank.ddcms.service;

import com.webank.ddcms.vo.common.CommonResponse;

public interface MenuService {

  CommonResponse getMenuByRole();
}
