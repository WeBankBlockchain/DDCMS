package com.webank.ddcms.controller;

import cn.hutool.json.JSON;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.webank.ddcms.dao.entity.CommuserInfoEntity;
import com.xkcoding.http.config.HttpConfig;
import me.zhyd.oauth.config.AuthConfig;
import me.zhyd.oauth.enums.scope.AuthGithubScope;
import me.zhyd.oauth.model.AuthCallback;
import me.zhyd.oauth.model.AuthResponse;
import me.zhyd.oauth.request.AuthGiteeRequest;
import me.zhyd.oauth.request.AuthGithubRequest;
import me.zhyd.oauth.request.AuthRequest;
import me.zhyd.oauth.utils.AuthScopeUtils;
import me.zhyd.oauth.utils.AuthStateUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;

/**
 * @author 张宇豪
 * @date 2023/9/3 23:53
 * @desc Github授权接口
 */

@RestController
@RequestMapping("/api/github")
public class GithubController {

    /**
     * 发送Github的授权请求
     * @param response 响应体
     * @throws IOException 抛出异常
     */
    @GetMapping("/render")
    public void renderAuth(HttpServletResponse response) throws IOException {
        AuthRequest authRequest = getAuthRequest();
        String authorize = authRequest.authorize(AuthStateUtils.createState());
        response.sendRedirect(authorize);
//        response.sendRedirect(authRequest.authorize(AuthStateUtils.createState()));
    }

    /**
     * 回调函数获取账户信息数据
     * @param callback 回调函数
     * @return 返回对象类型数据
     */
    @GetMapping("/callback")
    public Object login(AuthCallback callback) {
        AuthRequest authRequest = getAuthRequest();
        AuthResponse login = authRequest.login(callback);
        JSONObject jsonData = JSONUtil.parseObj(login.getData());
        // 获取Github的字段
        CommuserInfoEntity commuserInfoEntity = new CommuserInfoEntity();
        commuserInfoEntity.setType(1);
        commuserInfoEntity.setSource(jsonData.getStr("source"));
        commuserInfoEntity.setAvatar(jsonData.getStr("avatar"));
        commuserInfoEntity.setCommUsername(jsonData.getStr("username"));

        // 获取accessToken
        JSONObject jsonToken = JSONUtil.parseObj(jsonData.get("token"));
        commuserInfoEntity.setAccessToken(jsonToken.getStr("accessToken"));
        return commuserInfoEntity;
    }

    /**
     * 连接Github的个人应用信息
     * @return 返回结果
     */
    private AuthRequest getAuthRequest() {
        return new AuthGithubRequest(AuthConfig.builder()
                .clientId("3d90c8473462cfa79a01")
                .clientSecret("c7beff7b2690494b8b3f71cb7662318fe7c83")
                .redirectUri("http://localhost:10880/api/github/callback/")
                .scopes(AuthScopeUtils.getScopes(AuthGithubScope.values()))
                .httpConfig(HttpConfig.builder()
                        .timeout(15000)
                        .proxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress("127.0.0.1", 7890)))
                        .build())
                .build());
    }
}
