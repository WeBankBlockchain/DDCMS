package com.webank.ddcms.dao.entity;

import lombok.Data;
import lombok.experimental.Accessors;
import java.beans.Transient;

/**
 * @author zyh
 * @date 2023/9/4 3:51
 * @desc IntelliJ IDEA
 */

@Data
@Accessors(chain = true)

public class CommuserInfoEntity {

    private Long pkId;

    // 第三方账户用户名
    private String commUsername;
    // 本地账户用户名
    private String accountUsername;
    // 第三方类型（1、Gitee 2、Github）
    private Integer type;
    // 第三方账户头像
    private String avatar;
    // 第三方账户来源
    private String source;
    // 第三方的AccessToken
    private transient String accessToken;
}
