package com.webank.ddcms.enums;

// 审核状态
public enum ReviewStatus {
  NotReviewed,

  Approved,

  Denied
}
