package com.webank.ddcms;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ServerApplicationTests {
}
